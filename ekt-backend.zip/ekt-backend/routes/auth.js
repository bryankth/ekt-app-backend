const { Router } = require('express')
const { check } = require('express-validator')
const router = Router();
const { createUser, loginUser, revalidateToken } = require('../controllers/auth')
const { validate } = require('../middlewares/validate')
const { validateJWT } = require('../middlewares/validateJWT')
router.post(
    '/register',
     [//middlewares
        check('name', 'El nombre es obligatorio').not().isEmpty(),
        check('email', 'El email es obligatorio').isEmail(),
        check('password', 'El password debe de ser de más de 6 caracteres').isLength({ min: 6 }),
        validate,
     ], 
     createUser);

router.post(
    '/',
    [
        check('email', 'El email es obligatorio').isEmail(),
        check('password', 'El password debe de ser de más de 6 caracteres').isLength({ min: 6 }),
        validate,
    ],
    loginUser);

router.get('/renew', validateJWT, revalidateToken);

module.exports = router;