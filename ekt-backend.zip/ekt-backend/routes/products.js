const { Router } = require("express");
const { validateJWT } = require('../middlewares/validateJWT')
const { getProducts, createProduct, updateProduct, deleteProduct } = require('../controllers/products')
const { check } = require('express-validator')
const { validate } = require('../middlewares/validate')

const router = Router()
router.use( validateJWT )
router.get('/', getProducts)

router.post('/', [
    check('name', 'El nombre es obligatorio').not().isEmpty(),
    validate
], createProduct)

router.put('/:id', updateProduct)

router.delete('/:id', deleteProduct)


module.exports = router